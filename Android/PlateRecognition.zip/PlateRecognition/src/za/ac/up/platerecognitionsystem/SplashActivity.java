package za.ac.up.platerecognitionsystem;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.content.Intent;

public class SplashActivity extends Activity
{
	private final int SPLASH_DISPLAY_LENGHT = 5000; 
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);
		try 
		{
			new Handler().postDelayed(new Runnable()
			{             
				@Override             
				public void run() 
				{  
					Intent mainIntent = new Intent("za.ac.up.platerecognitionsystem.Login");                
					startActivity(mainIntent);           
					finish();
				}//end run()       
			}, SPLASH_DISPLAY_LENGHT); 	
		}//end try
		catch(Exception e)
		{
			e.printStackTrace();
		}//end catch(Exception e)
	}//end onCreate()
}//end class SplashActivity