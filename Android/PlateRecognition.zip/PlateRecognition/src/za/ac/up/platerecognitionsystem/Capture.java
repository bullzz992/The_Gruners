package za.ac.up.platerecognitionsystem;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Capture extends Activity
{
	final int CAMERA_CAPTURE = 1;
	final int PIC_CROP = 2;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.capture);
		
		Button captureBtn = (Button)findViewById(R.id.btnCapturePlate);	
		captureBtn.setOnClickListener(new OnClickListener()
		{			
			@Override
			public void onClick(View v)
			{
				if(v.getId()==R.id.btnCapturePlate)
				{
					try
					{
						//launch camera
						Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
						startActivityForResult(captureIntent, CAMERA_CAPTURE);
					}//end try
					catch(ActivityNotFoundException anfe)
					{
						String errorMessage = "Your device doesn't support capturing images!";
						Toast toast = Toast.makeText(getBaseContext(), errorMessage, Toast.LENGTH_SHORT);
						toast.show();
					}//end catch()
				}//end if
			}//end onClick()
		});//end Button
	}//end onCreate	
}//end class