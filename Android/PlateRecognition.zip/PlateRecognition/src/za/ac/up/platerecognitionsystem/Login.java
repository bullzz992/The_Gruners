package za.ac.up.platerecognitionsystem;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends Activity
{
	TextView username;
	TextView password;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);		
		try 
		{
			username = (TextView) findViewById(R.id.txtUsername);
			password = (TextView) findViewById(R.id.txtPassword);
			
			Button btnLogin = (Button) findViewById(R.id.btnLogin);
			btnLogin.setOnClickListener(new OnClickListener()
			{				
				@Override
				public void onClick(View arg0) 
				{
					if(username.getText().length() > 0)
					{
						if(password.getText().length() > 0)
						{
							Intent i = new Intent("za.ac.up.platerecognitionsystem.Home");
							startActivity(i);
						}//end if
						else
						{
							LayoutInflater inflater = getLayoutInflater();
							View layout = inflater.inflate(R.layout.toast, (ViewGroup) findViewById(R.id.toast_layout_root));
							TextView text = (TextView) layout.findViewById(R.id.text);
							text.setText("Please enter password!");
							Toast toast = new Toast(getApplicationContext());
							toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
							toast.setDuration(Toast.LENGTH_LONG);
							toast.setView(layout);
							toast.show();
						}//end else
					}//end if
					else
					{
						LayoutInflater inflater = getLayoutInflater();
						View layout = inflater.inflate(R.layout.toast, (ViewGroup) findViewById(R.id.toast_layout_root));
						TextView text = (TextView) layout.findViewById(R.id.text);
						text.setText("Please enter username!");
						Toast toast = new Toast(getApplicationContext());
						toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
						toast.setDuration(Toast.LENGTH_LONG);
						toast.setView(layout);
						toast.show();
					}//end else
				}//end onClick()
			});//end button
		}//end try
		catch(Exception e)
		{
			e.printStackTrace();
		}//end catch()
	}//end onCreate()
}//end class Login