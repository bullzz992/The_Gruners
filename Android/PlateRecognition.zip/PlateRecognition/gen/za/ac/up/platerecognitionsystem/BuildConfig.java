/** Automatically generated file. DO NOT MODIFY */
package za.ac.up.platerecognitionsystem;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}